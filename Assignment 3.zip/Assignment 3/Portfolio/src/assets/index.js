// Logo
import logo from './logo/logo.jpg';

// Technologies
import viteIcon from './tech/vite.svg';
import close from './close.svg';
import menu from './menu.svg';

// Avatar
import avatar from './avatar/avatar.png';

export {
  menu,
  close,
  viteIcon,
  avatar,
  logo,
};
