
import NavBar from "../Components/nav/NavBar";
import Hero from "../Pages/Hero";
import About from "../Pages/About";
import Contact from "../Pages/Contact";

function App() {
  return (
    <>
      <NavBar />
      <Hero />
      <About />
      <Contact />
    </>
  );
}

export default App;
