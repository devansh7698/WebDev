from django.db import models

class User(models.Model):
    username = models.CharField(primary_key=True, max_length=100)
    password = models.CharField(max_length=100)
    email = models.EmailField()
    balance = models.DecimalField(max_digits=10, decimal_places=2)

class Transaction(models.Model):
    from_username = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sender_transactions')
    to_username = models.ForeignKey(User, on_delete=models.CASCADE, related_name='receiver_transactions')
    transaction_id = models.AutoField(primary_key=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
