from rest_framework import serializers
from app.models import User, Transaction

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = '__all__'

    def validate(self, data):
        from_username = data['from_username']
        amount = data['amount']
        if from_username.balance < amount:
            raise serializers.ValidationError("Insufficient balance.")
        return data

    def create(self, validated_data):
        from_username = validated_data['from_username']
        to_username = validated_data['to_username']
        amount = validated_data['amount']

        # Update the balance of the sender
        from_username.balance -= amount
        from_username.save()

        # Update the balance of the receiver
        to_username.balance += amount
        to_username.save()

        # Create the transaction
        transaction = Transaction.objects.create(
            from_username=from_username,
            to_username=to_username,
            amount=amount
        )
        return transaction
